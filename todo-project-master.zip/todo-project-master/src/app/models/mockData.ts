import { ToDoModel } from "./todoModel";

// prefilled mock data
export const MOCKDATA:ToDoModel[]=[
    {taskName:'Complete Angular Course',status:'incomplete'},
    {taskName:'Learn mongoDB',status:'incomplete'}
]
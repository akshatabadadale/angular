//model to store our todo objects
export class ToDoModel{
    public taskName:string;
    public status:string;
}